﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineBikeRentalSystem.Models;
using System.Data.Entity;

namespace OnlineBikeRentalSystem.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Gallery()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult Registration()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Booking()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Registration(UserTB userTB)
        {
            using (BikeRentalEntities entities = new BikeRentalEntities()) 
            {
                if(ModelState.IsValid)
                {
                    entities.UserTBs.Add(userTB);
                    entities.SaveChanges();
                    ViewBag.Message = "Register Sucessfully"; ;
                   ModelState.Clear();
                }
            }
            return View(userTB);
        }
        [HttpPost]
        public ActionResult Contact(ContactTB contactTB)
        {
            using (BikeRentalEntities entities = new BikeRentalEntities())
            {
                if (ModelState.IsValid)
                {
                    entities.ContactTBs.Add(contactTB);
                    entities.SaveChanges();
                    ViewBag.Message = "Register Sucessfully"; ;
                    ModelState.Clear();
                }
            }
            return View(contactTB);
        }
        [HttpPost]
        public ActionResult Booking(BookingTB bookingTB)
        {
            using (BikeRentalEntities entities = new BikeRentalEntities())
            {
                if (ModelState.IsValid)
                {
                    entities.BookingTBs.Add(bookingTB);
                    entities.SaveChanges();
                    ViewBag.Message = "Booking Confirm"; ;
                    ModelState.Clear();
                }
            }
            return View(bookingTB);
        }
        [HttpPost]
        public ActionResult Login(UserTB userTB)
        {
            using (BikeRentalEntities entities = new BikeRentalEntities())
            {
                if (ModelState.IsValid)
                {
                    var obj = entities.UserTBs.Where(a => a.email.Equals(userTB.email) && a.pass.Equals(userTB.pass)).FirstOrDefault();
                    if (obj != null)
                    {
                        //Session["UserID"] = obj.UserId.ToString();
                        //Session["UserName"] = obj.email.ToString();
                        return RedirectToAction("Home/Booking");
                    }
                    ModelState.Clear();
                }
            }
            return View(userTB);
        }

    }
}